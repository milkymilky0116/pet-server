
import pandas as pd
from sklearn.preprocessing import LabelEncoder, MinMaxScaler
import numpy as np

def parse_range(value):
    try:
        low, high = map(float, value.split('-'))
        return (low + high) / 2
    except:
        return 0

def prepare_vectors(user_df, df, mode="bi"):
    data = df.copy()

    # 기본 전처리
    for col in ['애견 모색', '애견 성격', '애견 지역', '예방접종']:
        le = LabelEncoder()
        data[col] = le.fit_transform(data[col].astype(str))
        user_df[col] = le.transform(user_df[col].astype(str))

    if mode == "bi":
        for col in ['preference_모색', 'preference_성격', 'preference_지역', 'preference_예방접종']:
            le = LabelEncoder()
            data[col] = le.fit_transform(data[col].astype(str))
            user_df[col.replace('preference_', '')] = le.transform(user_df[col.replace('preference_', '')].astype(str))

        data['preference_나이'] = df['preference 연령 range (개월)'].map(parse_range)
        data['preference_체중'] = df['preference_몸무게 range (kg)'].map(parse_range)

        feature_cols = ['애견 나이(개월)', '애견 몸무게(kg)', '애견 모색', '애견 성격', '애견 지역', '예방접종',
                        'preference_모색', 'preference_성격', 'preference_지역', 'preference_예방접종',
                        'preference_나이', 'preference_체중']
    else:
        feature_cols = ['애견 나이(개월)', '애견 몸무게(kg)', '애견 모색', '애견 성격', '애견 지역', '예방접종']

    scaler = MinMaxScaler()
    features = scaler.fit_transform(data[feature_cols])
    gps = data[['lat', 'lon']].values
    ids = data['ID'].values
    names = data['애견 이름'].values

    return user_df, features, gps, ids, names
